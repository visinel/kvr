# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcaddon, urllib, re, xbmcplugin, os, urlparse, json

import urlresolver
from resources.lib import client
from resources.lib import control
from resources.lib import metainfo
from resources.lib import metacache


REMOTE_DBG = False

class InputWindow(xbmcgui.WindowDialog):
    def __init__(self, *args, **kwargs):
        self.cptloc = kwargs.get('captcha')
        self.img = xbmcgui.ControlImage(335,30,624,60,self.cptloc)
        self.addControl(self.img)
        self.kbd = xbmc.Keyboard()

    def get(self):
        self.show()
        self.kbd.doModal()
        if (self.kbd.isConfirmed()):
            text = self.kbd.getText()
            self.close()
            return text
        self.close()
        return False


thisAddon = xbmcaddon.Addon(id='plugin.video.mooviecc')
UserDataDir = xbmc.translatePath(thisAddon.getAddonInfo('profile') ).decode('utf-8')
if sys.platform == 'win32':
    captcha_tmp = UserDataDir + '\\captcha.png'
else:
    captcha_tmp = UserDataDir + '/captcha.png'


mooviecc_url = control.setting('mooviecc_url')
addon_handle = int(sys.argv[1])


def setviewmode(mode):
    mainview = int(control.setting('mainview'))
    streamview = int(control.setting('streamview'))
    viewmodes = [0, 502, 51, 500, 501, 508, 504, 503, 515]
    
    if mode == 'main_folder':
        return viewmodes[mainview]
    elif mode == 'movie_folder':
        return viewmodes[streamview]          


def home():
    addDir('Filmek',                     '', 1, '', '', '1', 1, '', '', '')
    addDir('Sorozatok',                  '', 1, '', '', '2', 1, '', '', '')
    addDir('Keresés',                    '', 5, '', '', '', 1, '', '', '')
    return


def filmek():
    addDir('Legújabb',                  '', 2, '', '', description, 1, 'new', '', '')
    addDir('Legfrissebb (megjelenés)',  '', 2, '', '', description, 1, 'year', '', '')
    addDir('Legnézettebb',              '', 2, '', '', description, 1, 'most_watched', '', '')
    addDir('Legjobbra értékelt',        '', 2, '', '', description, 1, 'most_pop', '', '')
    addDir('Kategóriák',                '', 12, '', '', description, 1, 'most_watched', '', '')
    return


def listak():
    m = 3 if description == '1' else 8
    gen = '|genres:%s,|' % title if not title == '' else ''
    query = urlparse.urljoin(mooviecc_url, '/core/ajax/movies.php')
    post = urllib.urlencode({'type': 'get_movies', 'query': 'type:' + description + '|sort:' + category + '|page:' + str(page) + gen})
    i = client.request(query, post = post)
    
    result = client.parseDOM(i, 'li', attrs={'class': 'movie_cover_li'})
    for item in result:
        try:
            url = client.parseDOM(item, 'a', ret='href')[0]
            url = urlparse.urljoin(mooviecc_url, url)
            
            img = client.parseDOM(item, 'img', ret='src')[0]
            img = urlparse.urljoin(mooviecc_url, img)
            
            titl = client.parseDOM(item, 'a', ret='bubble')[0]
            titl = client.replaceHTMLCodes(titl)
            titl = titl.encode('utf-8')
            
            addDir(titl, url, m, img, img, description, 1, '', '', '')
        except:
            pass
    if not 'class="pgNext pgEmpty"' in i:
        addDir('[COLOR green]Következő oldal[/COLOR]', '', 2, '', '', description, page + 1, category, '', gen)
    viewmode = setviewmode('main_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return


def kategoriak():
    i = client.request(mooviecc_url)
    result = client.parseDOM(i, 'select', attrs={'id': 's_genres'})
    genre = client.parseDOM(result, 'option')
    id = client.parseDOM(result, 'option', ret='value')
    result = zip(genre, id)
    
    for item in result:
        try:
            id = item[1]
            id = id.encode('utf-8')
            
            genre = item[0]
            genre = genre.encode('utf-8')
            addDir(genre, '', 2, '', '', description, 1, 'new', '', id)
        except:
            pass


def getType():
    i =  client.request(url)
    titl = client.parseDOM(i, 'div', attrs={'id': 'content'})
    titl = client.parseDOM(titl, 'h1')[0]
    titl = titl.encode('utf-8')
    if 'online sorozat' in titl.lower():
        m = 8
    else:
        m = 3

    control.sleep(200)

    control.execute('Container.Update(%s?mode=%s&name=%s&url=%s&iconimage=%s)' % (sys.argv[0], str(m), urllib.quote_plus(name), urllib.quote_plus(url), urllib.quote_plus(iconimage)))


def forrasok_Film():
    i =  client.request(url)
    
    movie_sheet = client.parseDOM(i, 'div', attrs={'id': 'movie_sheet'})[0]
    
    meta = metacache.get(metainfo.get_meta, 720, movie_sheet, name, 'movie')

    host_url = client.parseDOM(i, 'div', attrs={'class': 'streamBtn'})
    
    if not host_url:
        control.infoDialog(u'Nincs el\u00E9rhet\u0151 link!'); sys.exit()

    host_url = client.parseDOM(host_url, 'a', ret='href')[0]
    host_url = host_url.encode('utf-8')
    r = client.request(host_url)

    result = client.parseDOM(r, 'tr', attrs={'class': 'jsPlay'})
    host_list = get_hosts(result)
    
    for item in host_list:
        try:
            addFile('[COLOR blue]%s[/COLOR] | %s | [COLOR green]%s[/COLOR]' % (item['quality'], item['lang'], item['host']), name, urlparse.urljoin(host_url, item['url']), 4, iconimage, meta)
        except:
            pass
    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return


def forrasok_Sorozat():    
    meta = json.loads(metastring)
    host_url = description
    season = meta['season'].encode('utf-8')
    episode = meta['episode'].encode('utf-8')

    result = client.parseDOM(url, 'tr', attrs={'class': 'jsPlay'})
    host_list = get_hosts(result)

    for item in host_list:
        try:
            addFile('%sx%s | [COLOR blue]%s[/COLOR] | %s | [COLOR green]%s[/COLOR]' % (season, episode, item['quality'], item['lang'], item['host']), title, urlparse.urljoin(host_url, item['url']), 4, iconimage, meta)            
        except:
            pass

    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return


def get_hosts(list):
    host_list = []
    hostDict = getConstants()

    for item in list:
        try:
            host = client.parseDOM(item, 'td')[2].split('.')[0].strip()
            if not host.lower() in hostDict: raise Exception()
            host = host.encode('utf-8')
            
            quality = client.parseDOM(item, 'span')[0]
            quality = quality.encode('utf-8')
            
            lang = client.parseDOM(item, 'img', ret='data-tooltip')[0]
            lang = lang.encode('utf-8')
            
            link = client.parseDOM(item, 'a', ret='href')[0]
            link = link.encode('utf-8')
            
            host_list.append({'host': host, 'quality': quality, 'lang': lang, 'url': link})
        except:
            pass
    return host_list


def solvecaptcha(location, top_url):
    mvcookie = client.request(top_url, output = 'cookie')
    try: capcha = client.parseDOM(location, 'img', attrs={'src': '/captchaimg.php'}, ret='src')[0]
    except: capcha = ''
    if capcha != '' :
        parsed = urlparse.urlparse(top_url)
        captcha_url = parsed.scheme + '://' + parsed.netloc + '/captchaimg.php'
        captcha_img = client.request(captcha_url, cookie = mvcookie)
        captcha_file = open(captcha_tmp,'wb')
        captcha_file.write(captcha_img)
        captcha_file.close()
        solver = InputWindow(captcha = captcha_tmp)
        solution = solver.get()
        postdata = urllib.urlencode({'captcha':solution,'submit':'Ok'})
        location = client.request(top_url, redirect=True, cookie=mvcookie, post=postdata)
    return location


def getvideo():
    try: 
        control.busy()
        subs = url.find('http',1)
        rep = url
        if subs > 1: rep = url[subs:] 
        r = client.request(rep)
        r = solvecaptcha(r,rep)
        result = client.parseDOM(r, 'div', attrs={'class':'embedHolder'})
        try: u = client.parseDOM(result, 'iframe', ret='src')[0]
        except: u = client.parseDOM(result, 'IFRAME', ret='SRC')[0]
        u = u.encode('utf-8')

        direct_url = None
        hmf = urlresolver.HostedMediaFile(url=u, include_disabled=True, include_universal=False)
        if hmf.valid_url() == True: direct_url = hmf.resolve()
        if direct_url == False or direct_url == None: raise Exception()
        
        meta = json.loads(metastring)
        meta.update({'title': title, 'tvshowtitle': title})
        
        if 'episode' in meta: label = '%s %sx%s' % (title, meta['season'].encode('utf-8'), meta['episode'].encode('utf-8'))
        else: label = title

        videoitem = xbmcgui.ListItem(label=label, thumbnailImage=iconimage)
        videoitem.setInfo(type='Video', infoLabels=meta)
        
        control.idle()
        
        xbmc.Player().play(direct_url, videoitem)
        
        if 'imdb' in meta:
                control.window.setProperty('script.trakt.ids', json.dumps({'imdb': meta['imdb']}))
    except:
        control.idle()
        control.infoDialog(u'Lej\u00E1tsz\u00E1s sikertelen')

def open_search_panel():
    try:
        control.idle()

        k = control.keyboard('', 'Keresés') ; k.doModal()
        q = k.getText() if k.isConfirmed() else None

        if (q == None or q == ''): return

        searchMovies(q)
    except:
        return
    
def searchMovies(keywords): 
    post = urllib.urlencode({'type': 'instant_search', 'query': keywords})
    query = urlparse.urljoin(mooviecc_url, '/core/ajax/movies.php')
    r = client.request(query, post=post)
    result = client.parseDOM(r, 'li')
    if len(result) == 0: return

    for item in result:
        try:
            title = client.parseDOM(item, 'span', attrs={'class': 'r-title'})[0]
            title = title.encode('utf-8')
            
            img = client.parseDOM(item, 'img', ret='src')[0]
            img = urlparse.urljoin(mooviecc_url, img)
            img = img.encode('utf-8')
            
            link = client.parseDOM(item, 'a', ret='href')[0]
            link = urlparse.urljoin(mooviecc_url, link)
            link = link.encode('utf-8')
            addFile(title, '', link, 11, img, {})
        except:
            pass
    viewmode = setviewmode('main_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)


def getSeason(): 
    r = client.request(url)

    movie_sheet = client.parseDOM(r, 'div', attrs={'id': 'movie_sheet'})[0]

    meta = metacache.get(metainfo.get_meta, 720, movie_sheet, name, 'tvshow')

    query = client.parseDOM(r, 'div', attrs={'class': 'streamBtn'})
    
    if not query:
        control.infoDialog(u'Nincs el\u00E9rhet\u0151 link!'); sys.exit()
    
    query = client.parseDOM(query, 'a', ret='href')[0]
    query = query.encode('utf-8')
    
    r = client.request(query)
    
    result = client.parseDOM(r, 'content', attrs={'class': 'fL'})
    result = client.parseDOM(result, 'nav')
    seasons = client.parseDOM(result, 'a', ret='href')
    #seasons = sorted(set(seasons))

    for item in seasons:
        try:
            a = re.search('\/(\d+)-evad', item).group(1)
            meta.update({'season': a})
            addDir('%s. évad' % a.encode('utf-8'), urlparse.urljoin(query, item.encode('utf-8')), 9, iconimage, '', '', '', '', meta, name)
        except:
            pass

    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return


def getEpisodes():
    meta = json.loads(metastring)
    season = meta['season'].encode('utf-8')

    r = client.request(url)
    result = client.parseDOM(r, 'div', attrs={'class': 'seasonList'})
    episodes = client.parseDOM(result, 'div', attrs={'class': 'item'})
    for item in episodes:
        try:
            a = client.parseDOM(item, 'input', ret='id')[0]
            meta.update({'episode': a})
            addDir('%s. évad %s. epizód' % (season, a.encode('utf-8')), item.encode('utf-8'), 10, iconimage, '', url, '', '', meta, title)   
        except:
            pass

    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return


def getConstants():
        hostcapDict = ['kingfiles', 'openload', 'thevideo', 'torba', 'flashx']
        try:
            try: hostDict = urlresolver.relevant_resolvers(order_matters=True)
            except: hostDict = urlresolver.plugnplay.man.implementors(urlresolver.UrlResolver)
            hostDict = [i.domains for i in hostDict if not '*' in i.domains]
            hostDict = [i.lower() for i in reduce(lambda x, y: x+y, hostDict)]
            hostDict = [i.rsplit('.', 1)[0] for i in hostDict]
            hostDict = list(set(hostDict))
            if control.setting('hostcap') == 'true':
                hostDict = [i for i in hostDict if not i in hostcapDict]
        except:
            hostDict = []
        return hostDict


def get_trailer():
    try:
        from resources.lib import trailer
        trailer.trailer().play(name)
    except:
        return


def addDir(name, url, mode, iconimage, fanart, description, page, category, meta, title):
    if meta == '': meta = {'fanart': '0'}
    if 'poster' in meta: poster = meta['poster']
    else: poster = iconimage
    metastring = json.dumps(meta)
    if 'fanart' in meta and not meta['fanart'] == '0': fanart = meta['fanart']
    else: fanart = poster
    if 'episode' in meta: type = 'episodes'
    elif 'season' in meta and not 'episode' in meta: type = 'tvshows'
    else: type = 'movies'
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&category="+str(category)+"&page="+str(page)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&metastring="+urllib.quote_plus(metastring)+"&title="+urllib.quote_plus(title)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
    liz.setInfo( type="Video", infoLabels=meta )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    xbmcplugin.setContent(addon_handle, type)
    return ok

def addFile(name, title, url, mode, iconimage, meta):
    metastring = json.dumps(meta)
    if 'poster' in meta: poster = meta['poster']
    else: poster = iconimage
    if 'fanart' in meta and not meta['fanart'] == '0': fanart = meta['fanart']
    else: fanart = poster
    type = 'episodes' if 'episode' in meta else 'movies'
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&title="+urllib.quote_plus(title)+"&metastring="+urllib.quote_plus(metastring)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
    liz.setInfo( type="Video", infoLabels=meta )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    xbmcplugin.setContent(addon_handle, type)
    return ok

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = None
page = 0
category = ''
search_text = ''
title = ''

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    title = urllib.unquote_plus(params["title"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    page = int(params["page"])
except:
    pass
try:        
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass
try:        
    category = urllib.unquote_plus(params["category"])
except:
    pass
try:        
    search_text = urllib.unquote_plus(params["category"])
except:
    pass
try:        
    metastring = urllib.unquote_plus(params["metastring"])
except:
    pass


if mode == None:
    home()
elif mode == 1:
    filmek()
elif mode == 2:
    listak()
elif mode == 3:
    forrasok_Film()
elif mode == 4:
    getvideo()
elif mode == 5:
    open_search_panel()
elif mode == 7:
    sorozatok()
elif mode == 8:
    getSeason()
elif mode == 9:
    getEpisodes()
elif mode == 10:
    forrasok_Sorozat()
elif mode == 11:
    getType()
elif mode == 12:
    kategoriak()
elif mode == 13:
    get_trailer()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
