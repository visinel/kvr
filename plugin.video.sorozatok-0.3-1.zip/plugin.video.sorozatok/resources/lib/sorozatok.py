# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import sys,xbmcgui,urllib,re,urlparse,json

from resources.lib import client
from resources.lib import cache
from resources.lib import control
from resources.lib import cookiecache
from resources.lib import directory


class indexer:
    def __init__(self):
        self.list = []
        self.main_url = ('http://srnet.eu')
        self.email = control.setting('email')
        self.password = control.setting('password')
        self.cookie = cookiecache.get(self.login, 24, 'cookie')
        if not 'hash' in self.cookie.lower():
            cookiecache.clear(); control.infoDialog(u'Bejelentkez\u00E9s sikertelen!', icon='WARNING'); sys.exit()


    def get_series(self, order=None, fav_list=None, page='1', search_text=None):
        try:
            query = urlparse.urljoin(self.main_url, '/api/search.json')
            json_data = cache.get(client.request, 1, query, cookie=self.cookie)
            json_data = json.loads(json_data)

            result = []
            if not order == None:
                query = urlparse.urljoin(self.main_url, '/channels.php?order%s&page=%s' % (order, page))
                r = client.request(query, cookie=self.cookie)
                result = client.parseDOM(r, 'div', attrs={'id': 'videolist-content'})
                result = client.parseDOM(result, 'a', ret='data-id')

            elif not fav_list == None:
                result = fav_list

            if result:
                for i in result:
                    for x in json_data:
                        if i == x['cat_id']: self.list.append(x)

            elif not search_text == None:
                self.list = [i for i in json_data if search_text in i.get('cat_name').lower().encode('utf-8') or search_text in i.get('cat_eng').lower().encode('utf-8')]

            if self.list == []: raise Exception()

            for i in self.list: i.update({'title': i['cat_name'], 'url': urlparse.urljoin(self.main_url, '/%s-online' % i['url']), 'data_id': i['cat_id'], 'image': urlparse.urljoin(self.main_url, '/o/c/%02d.jpg' % int(i['cat_id'])), 'year': i['year'], 'action': 'season'})

            try:
                if fav_list == None:
                    from resources.lib import favorites
                    fav_list = favorites.getFavorites()

                for i in self.list: 
                    if i['data_id'] in fav_list:
                        i.update({'cm': [{'title': '%s %s %s' % (u'Elt\u00E1vol\u00EDt\u00E1s', control.addonInfo('name'), u'kedvencekb\u0151l'), 'query': {'action': 'delete_favorite', 'data_id': i['data_id']}}]})
                    else:
                        i.update({'cm': [{'title': '%s %s %s' % (u'Hozz\u00E1ad\u00E1s', control.addonInfo('name'), 'kedvencekhez'), 'query': {'action': 'add_favorite', 'title': i['title'].encode('utf-8'), 'data_id': i['data_id']}}]})
            except:
                pass

            try:
                next = client.parseDOM(r, 'ul', attrs={'class': 'pagination.+?'})[-1]
                if 'class="next"' in next:
                    for i in self.list: i.update({'nextaction': order, 'page': str(int(page) + 1)})
            except:
                pass

            directory.add(self.list, content='tvshows', mediatype='tvshow')
        except:
            control.infoDialog(u'Nincs tal\u00E1lat')
            return


    def get_seasons(self, meta):
        meta = json.loads(meta)
        title, image, year, url = meta['title'], meta['image'], meta['year'], meta['url']
        query = urlparse.urljoin(self.main_url, url)
        r = client.request(query, cookie=self.cookie)
        result = client.parseDOM(r, 'div', attrs={'class': 'loop-content owl-carousel2 hide'})
        result = [(re.search('\s(\d+)\..+?\s\d+\.', i).group(1), i) for i in result]
        result = sorted(result, key=lambda x: int(x[0]))
        
        result2 = client.parseDOM(r, 'div', attrs={'class': 'panel-body'})
        try: 
            plot = client.parseDOM(result2, 'p')[-1]
            plot = re.sub('^.+?/b>\s*\n*', '', plot)
            plot = client.replaceHTMLCodes(plot)
            plot = plot.encode('utf-8')
        except: plot = '0'
        
        try:
            imdb = re.search('/title/(tt\d{5,7})', result2[0]).group(1)
        except:
            imdb = '0'
        
        for i in result:
            try:
                label = '%s. %s' % (i[0], u'\u00C9vad')

                episodes = []
                epis = client.parseDOM(i[1], 'div', attrs={'class': 'video'})
                for item in epis:
                    try:
                        episode =  client.parseDOM(item, 'a', ret='title')[0]
                        episode = re.search('\d+\..+?\s(\d+)\.', episode).group(1)
                        
                        ep_label = '%s %s. %s' % (label, episode, u'epiz\u00F3d')

                        ep_image = client.parseDOM(item, 'img', ret='src')[0]
                        ep_image = urlparse.urljoin(self.main_url, ep_image)

                        ep_url = client.parseDOM(item, 'a', ret='href')[0]
                        ep_url = urlparse.urljoin(self.main_url, ep_url)

                        ep_id = client.parseDOM(item, 'a', ret='data-id')[0]

                        try:
                            duration = client.parseDOM(item, 'span', ret='alt')[0].strip()
                            duration = re.sub('\s.*$', '', duration).split(':')
                            if len(duration) == 2: duration = (int(duration[0]) * 60) + int(duration[1])
                            elif len(duration) == 3: duration = (int(duration[0]) * 3600) + (int(duration[1]) * 60) + int(duration[2])
                        except: duration = 0
                        
                        episodes.append({'label': ep_label, 'image': ep_image, 'url': ep_url, 'episode': episode, 'episode_id': ep_id, 'duration': str(duration)})
                    except:
                        pass

                self.list.append({'title': title, 'label': label, 'image': image, 'season': i[0], 'plot': plot, 'year': year, 'imdb': imdb, 'episodes': json.dumps(episodes), 'action': 'episodes'})
            except:
                pass

        try: control.property(int(sys.argv[1]), 'showplot', self.list[0]['plot'])
        except: pass

        directory.add(self.list, content='seasons', mediatype='season')


    def get_episodes(self, meta):
        meta = json.loads(meta)
        self.list = json.loads(meta['episodes'])
        for i in self.list: i.update({'action': 'resolve', 'title': meta['title'], 'season': meta['season'], 'year': meta['year'], 'plot': meta['plot'], 'imdb': meta['imdb'], 'isFolder': 'false'})
        directory.add(self.list, content='episodes', mediatype='episode')


    def source_resolve(self, meta):
        try:
            import urlresolver

            meta = json.loads(meta)
            url, image, episode_id = meta['url'], meta['image'], meta['episode_id']

            headers = {'Referer': url, 'Cookie': self.cookie}
            key = urlparse.parse_qsl(url)[0][1]
            query = urlparse.urljoin(self.main_url, '/embed.php?id=%s&key=%s' % (episode_id, key))
            r = client.request(query, headers=headers)

            headers.update({'Referer': query})
            result = client.parseDOM(r, 'div', attrs={'id': 'selector'})
            sources = zip(client.parseDOM(result, 'a', ret='href'), client.parseDOM(result, 'div'))
            sources = [(i[0], re.sub('\s*\(.*\)', '', i[1])) for i in sources]

            source = self.pick_source(sources)

            query = urlparse.urljoin(self.main_url, source)
            r = client.request(query, headers=headers)

            source = client.parseDOM(r, 'iframe', ret='src')[0]
            url = urlresolver.resolve(source)

            directory.resolve(url, meta=meta, icon=image)

            if 'imdb' in meta:
                control.window.setProperty('script.trakt.ids', json.dumps({'imdb': meta['imdb']}))
        except: 
            control.idle()
            return


    def search(self):
        try:
            control.idle()

            t = u'Keres\u00E9s'
            k = control.keyboard('', t) ; k.doModal()
            q = k.getText() if k.isConfirmed() else None

            if (q == None or len(q) < 3): raise Exception()

            url = '%s?action=search_result&search_text=%s' % (sys.argv[0], urllib.quote_plus(q.lower()))
            control.execute('Container.Update(%s)' % url)
        except:
            control.infoDialog(u'Legal\u00E1bb 3 karakter kell a keres\u00E9shez!', time=5000)
            return


    def pick_source(self, sources):
        hostcapDict = ['hugefiles', 'kingfiles', 'openload', 'oload', 'vidup', 'torba', 'thevideo', 'streamin']
        auto_pick = control.setting('auto_pick') == 'true'
        disable_hostcap = control.setting('hostcap') == 'true'
        if len(sources) == 1:
            return sources[0][0]
        elif len(sources) > 1:
            if auto_pick:
                if disable_hostcap:
                    sources = [i for i in sources if i[1].lower() not in hostcapDict]
                return sources[0][0]
            else:
                result = xbmcgui.Dialog().select(u'V\u00E1lassz t\u00E1rhelyet', [source[1] for source in sources])
                if result == -1:
                    return
                else:
                    return sources[result][0]


    def login(self, params):
        try:
            cookie = ''
            post = urllib.urlencode({'email': self.email, 'password': self.password, 'action': 'login', 'remember': 'on'})
            cookie = client.request(self.main_url, post=post, output='cookie', close=False)
            return cookie
        except:
            return cookie
