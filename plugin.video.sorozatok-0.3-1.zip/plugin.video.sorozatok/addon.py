# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import urlparse,sys

from resources.lib import control

REMOTE_DBG = False


# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        sys.path.append("C:\\Users\\User\\.p2\\pool\\plugins\\org.python.pydev_4.4.0.201510052309\\pysrc")
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)


if (control.setting('email') == '' or control.setting('password') == ''):
    l = control.yesnoDialog(u'A kieg\u00E9sz\u00EDt\u0151 haszn\u00E1lat\u00E1hoz regisztr\u00E1lj a [COLOR blue]http://srnet.eu/[/COLOR] weboldalon, ezut\u00E1n a be\u00E1ll\u00EDt\u00E1sokban add meg a bejelentkez\u00E9shez haszn\u00E1lt e-mail c\u00EDmet \u00E9s jelsz\u00F3t.'
                            , '', '', yeslabel=u'Be\u00E1ll\u00EDt\u00E1sok', nolabel=u'M\u00E9gse')
    if l == 1: control.openSettings()
    sys.exit()


params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))

action = params.get('action')

title = params.get('title')

data_id = params.get('data_id')

page = params.get('page', '1')

search_text = params.get('search_text')

meta = params.get('meta')

content = params.get('content')

if action == None:
    from resources.lib import navigator
    navigator.navigator().root()
    
elif action == 'viewsNavigator':
    from resources.lib import navigator
    navigator.navigator().views()

elif action == 'addView':
    from resources.lib import views
    views.addView(content)

elif action == 'clearCache':
    from resources.lib import navigator
    navigator.navigator().clearCache()

elif action == 'toolNavigator':
    from resources.lib import navigator
    navigator.navigator().tools()

elif action == 'openSettings':
    from resources.lib import control
    control.openSettings()

elif action == 'season':
    from resources.lib import sorozatok
    sorozatok.indexer().get_seasons(meta)

elif action == 'episodes':
    from resources.lib import sorozatok
    sorozatok.indexer().get_episodes(meta)

elif action == 'resolve':
    from resources.lib import sorozatok
    sorozatok.indexer().source_resolve(meta)

elif action == 'get_favorites':
    from resources.lib import favorites
    from resources.lib import sorozatok
    list = favorites.getFavorites()
    if not list == []: sorozatok.indexer().get_series(fav_list=list)

elif action == 'add_favorite':
    from resources.lib import favorites
    favorites.addFavorite(title, data_id)
    
elif action == 'delete_favorite':
    from resources.lib import favorites
    favorites.deleteFavorite(data_id)

elif action == 'search':
    from resources.lib import sorozatok
    sorozatok.indexer().search()

elif action == 'search_result':
    from resources.lib import sorozatok
    sorozatok.indexer().get_series(search_text=search_text)

elif action.startswith('='):
    from resources.lib import sorozatok
    sorozatok.indexer().get_series(order=action, page=page)
